public abstract class Greutate {
    abstract public int capacitate();
    abstract public int numarGreutati();
}
